//
//  SocketAddressFactory.hpp
//  networkplayground
//
//  Created by Erik Parreira on 2/18/16.
//  Copyright © 2016 Erik Parreira. All rights reserved.
//

#ifndef SocketAddressFactory_hpp
#define SocketAddressFactory_hpp

class SocketAddressFactory
{
public:
    
    static SocketAddressPtr CreateIPv4FromString( const string& inString );
};

#endif /* SocketAddressFactory_hpp */
