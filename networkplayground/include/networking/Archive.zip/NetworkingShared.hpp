//
//  NetworkingShared.hpp
//  networkplayground
//
//  Created by Erik Parreira on 2/20/16.
//  Copyright © 2016 Erik Parreira. All rights reserved.
//


// How do you include hpp files properly?
#include "NetworkBasics.hpp"